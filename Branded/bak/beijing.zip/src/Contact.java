/**
 * ������ϵ��
 */
package com.android.entity;

public class Contact {
	private	String userName;//(email); 
	private	String userId; 
	private	String firstName; 
	private	String lastName; 
	private	String nickName; 
	private	String contactStatus; 
	private	String contactGivenStatus; 
	private	String photoUrl;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getContactStatus() {
		return contactStatus;
	}
	public void setContactStatus(String contactStatus) {
		this.contactStatus = contactStatus;
	}
	public String getContactGivenStatus() {
		return contactGivenStatus;
	}
	public void setContactGivenStatus(String contactGivenStatus) {
		this.contactGivenStatus = contactGivenStatus;
	}
	public String getPhotoUrl() {
		return photoUrl;
	}
	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}

}
