package com.android.entity;

import java.util.List;

public class LastLocsInfo {
	public String getRet() {
		return ret;
	}
	public void setRet(String ret) {
		this.ret = ret;
	}
	public String getLastTime() {
		return lastTime;
	}
	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}
	public List<Loc> getLocInfoList() {
		return LocInfoList;
	}
	public void setLocInfoList(List<Loc> locInfoList) {
		LocInfoList = locInfoList;
	}
	private String ret;
	private String lastTime;
	private List<Loc> LocInfoList ;
}
