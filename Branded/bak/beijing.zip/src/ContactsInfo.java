/**
 * ��վ���ص���ϵ���б���Ϣ
 */
package com.android.entity;

import java.util.List;

public class ContactsInfo {
	private	String contactsNumber;
	private String groupsNumber;
	private List<Contact> contactList;

	public String getContactsNumber() {
		return contactsNumber;
	}
	public void setContactsNumber(String contactsNumber) {
		this.contactsNumber = contactsNumber;
	}
	public String getGroupsNumber() {
		return groupsNumber;
	}
	public void setGroupsNumber(String groupsNumber) {
		this.groupsNumber = groupsNumber;
	}
	public List<Contact> getContactList() {
		return contactList;
	}
	public void setContactList(List<Contact> contactList) {
		this.contactList = contactList;
	}
}
