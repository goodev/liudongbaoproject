package com.android.entity;

public class AckResult {

	public String getRV() {
		return RV;
	}
	public void setRV(String rv) {
		RV = rv;
	}
	public String getRM() {
		return RM;
	}
	public void setRM(String rm) {
		RM = rm;
	}
	public String getUsr() {
		return usr;
	}
	public void setUsr(String usr) {
		this.usr = usr;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getNn() {
		return nn;
	}
	public void setNn(String nn) {
		this.nn = nn;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getDu() {
		return du;
	}
	public void setDu(String du) {
		this.du = du;
	}
	public String getCpn() {
		return cpn;
	}
	public void setCpn(String cpn) {
		this.cpn = cpn;
	}
	public String getDid() {
		return did;
	}
	public void setDid(String did) {
		this.did = did;
	}
	public String getIdl() {
		return idl;
	}
	public void setIdl(String idl) {
		this.idl = idl;
	}
	public String getItv() {
		return itv;
	}
	public void setItv(String itv) {
		this.itv = itv;
	}
	public String getSdl() {
		return sdl;
	}
	public void setSdl(String sdl) {
		this.sdl = sdl;
	}
	public String getStv() {
		return stv;
	}
	public void setStv(String stv) {
		this.stv = stv;
	}
	public String getImax() {
		return imax;
	}
	public void setImax(String imax) {
		this.imax = imax;
	}
	public String getImin() {
		return imin;
	}
	public void setImin(String imin) {
		this.imin = imin;
	}
	public String getIinv() {
		return iinv;
	}
	public void setIinv(String iinv) {
		this.iinv = iinv;
	}
	public String getVer() {
		return ver;
	}
	public void setVer(String ver) {
		this.ver = ver;
	}
	public String getImguri() {
		return imguri;
	}
	public void setImguri(String imguri) {
		this.imguri = imguri;
	}
	public String getBcuri() {
		return bcuri;
	}
	public void setBcuri(String bcuri) {
		this.bcuri = bcuri;
	}
	public String getCpuri() {
		return cpuri;
	}
	public void setCpuri(String cpuri) {
		this.cpuri = cpuri;
	}
	public String getAduri() {
		return aduri;
	}
	public void setAduri(String aduri) {
		this.aduri = aduri;
	}
	//The meaning of the following, please refer to web site description. 
	private	String RV;
	private	String RM;

	private	String usr   ;
	private	String uid   ;
	private	String nn    ;
	private	String pic   ;
	private	String du    ;
	private	String cpn   ;
	private	String did   ;
	private	String idl   ;
	private	String itv   ;
	private	String sdl   ;
	private	String stv   ;
	private	String imax  ;
	private	String imin  ;
	private	String iinv  ;
	private	String ver   ;
	private	String imguri;
	private	String bcuri ;
	private	String cpuri ;
	private	String aduri ;
}
