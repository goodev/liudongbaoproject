package com.branded.android.entity;

public class Flyer {
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public String getFtitle() {
		return ftitle;
	}
	public void setFtitle(String ftitle) {
		this.ftitle = ftitle;
	}
	public String getFvdate() {
		return fvdate;
	}
	public void setFvdate(String fvdate) {
		this.fvdate = fvdate;
	}
	public int getPtype() {
		return ptype;
	}
	public void setPtype(int ptype) {
		this.ptype = ptype;
	}
	public int getRtype() {
		return rtype;
	}
	public void setRtype(int rtype) {
		this.rtype = rtype;
	}
	public int getPages() {
		return pages;
	}
	public void setPages(int pages) {
		this.pages = pages;
	}
	int    fid   ;
	String ftitle;
	String fvdate;
	int    ptype ;
	int    rtype ;
	int    pages ;
}
