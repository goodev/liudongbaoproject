/**
 * return by 	getcouponlist
 */
package com.branded.android.entity;

import java.util.List;

public class BaCouponInfo {
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public List<BaCoupon> getList() {
		return list;
	}
	public void setList(List<BaCoupon> list) {
		this.list = list;
	}
	int count;
	List<BaCoupon> list ;
}
