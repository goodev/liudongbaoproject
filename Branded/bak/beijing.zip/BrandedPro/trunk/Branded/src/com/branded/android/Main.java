package com.branded.android;

import java.io.IOException;
import java.util.List;

import org.apache.http.client.ClientProtocolException;

import com.branded.android.entity.Config;
import com.branded.android.entity.Store;
import com.branded.android.util.RestClient;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class Main extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		//RestClient.connect("http://ads.cellflare.com/Cfsrv/restservice/brand/getappbasic?bi=1&ptype=0&ver=1.0.0&fmt=json");
        try {
			List<Store> list = RestClient.getStoreCities("1","json");
			for(int i=0;i<list.size();i++){
				System.out.println(list.get(i).getCity()+","+list.get(i).getProv()+","+list.get(i).getCtry());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    }
}