package com.branded.android.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
 
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.branded.android.entity.BaCouponInfo;
import com.branded.android.entity.BaMessageInfo;
import com.branded.android.entity.Config;
import com.branded.android.entity.FlyerInfo;
import com.branded.android.entity.Store;
import com.branded.android.entity.StoreDetail;
import com.branded.android.entity.StoreInfo;
 
import android.graphics.Bitmap;
import android.util.Log;
 
public class RestClient {
 
	public static String getString(String url) throws ClientProtocolException, IOException{
        String result=null;
        HttpClient httpclient = new DefaultHttpClient();
        HttpGet httpget = new HttpGet(url); 
        HttpResponse response;
        InputStream instream=null;
            try {
				response = httpclient.execute(httpget);
				// Examine the response status
				Log.i("RestClient",response.getStatusLine().toString());
 
				// Get hold of the response entity
				HttpEntity entity = response.getEntity();
				if (entity != null) {
 
				    // A Simple JSON Response Read
				    instream = entity.getContent();
				    BufferedReader reader = new BufferedReader(new InputStreamReader(instream));
				    StringBuilder sb = new StringBuilder();
				    String line = null;
				    while ((line = reader.readLine()) != null) {
				        sb.append(line + "\n");
				    }
				    result = sb.toString();
				}
			} finally{
				if(instream!=null){
					instream.close();
				}
			}
        
        return result;
    }
	/**
	 * get basic and configuration of the app, include name, latest version, stores and/or list of images used for skin.
	 * @param bi     brandid, id of the branded app
	 * @param ptype  phone type                    
	 * @param ver    current version               
	 * @param fmt    return format, xml/json       
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 * example: http://ads.cellflare.com/Cfsrv/restservice/brand/getappbasic?bi=1&ptype=0&ver=1.0.0&fmt=json
	 */
    public static Config getAppBasic(String bi,String ptype,String ver,String fmt) throws ClientProtocolException, IOException{
    	String url = "http://ads.cellflare.com/Cfsrv/restservice/brand/getappbasic?";
    	url+="bi="+bi+"&ptype="+ptype+"&ver="+ver+"&fmt="+fmt;
    	String retStr = getString(url);
    	Config cfg = null;
        try {
			JSONObject json=new JSONObject(retStr);
			Log.i("RestClient","<jsonobject>\n"+json.toString()+"\n</jsonobject>");

			// A Simple JSONObject Parsing
			JSONArray nameArray=json.names();
			JSONArray valArray=json.toJSONArray(nameArray);
			cfg = new Config();
			for(int i=0;i<nameArray.length();i++)
			{
//			    Log.i("RestClient","<jsonname"+i+">\n"+nameArray.getString(i)+"\n</jsonname"+i+">\n"
//			            +"<jsonvalue"+i+">\n"+valArray.getString(i)+"\n</jsonvalue"+i+">");
			   String nameStr = nameArray.getString(i);
			   String valueStr  =valArray.getString(i);
			   if("cn".equalsIgnoreCase(nameStr)){cfg.setCn      (valueStr);}
			   if("bn".equalsIgnoreCase(nameStr)){cfg.setBn      (valueStr);}
			   if("scount".equalsIgnoreCase(nameStr)){cfg.setScount  (Integer.valueOf(valueStr).intValue());}
			   if("tid".equalsIgnoreCase(nameStr)){cfg.setTid     (Integer.valueOf(valueStr).intValue());}
			   if("lver".equalsIgnoreCase(nameStr)){cfg.setLver    (valueStr);}
			   if("phone".equalsIgnoreCase(nameStr)){cfg.setPhone   (valueStr);}
			   if("ft".equalsIgnoreCase(nameStr)){cfg.setFt      (Integer.valueOf(valueStr).intValue());}
			   if("img".equalsIgnoreCase(nameStr)){cfg.setImg     (valueStr);}
			   if("img_name".equalsIgnoreCase(nameStr)){cfg.setImg_name(valueStr);}
			   if("img_ver".equalsIgnoreCase(nameStr)){cfg.setImg_ver (Integer.valueOf(valueStr).intValue());}
			}

			// A Simple JSONObject Value Pushing
			//json.put("sample key", "sample value");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	return cfg;
    }
    public static Config getAppBasic() throws ClientProtocolException, IOException{
    	return getAppBasic("1","3","1.0.0","json");//android is 3
    } 
    
    
    
    
    /**
     * get cities list of store, when need search by cities, call it get the cities as list items for selection
     * @param bi
     * @param fmt
     * @return
     * @throws ClientProtocolException
     * @throws IOException
     * example:http://ads.cellflare.com/Cfsrv/restservice/brand/getstorecities?bi=1&fmt=xml
     */
    public static List<Store> getStoreCities(String bi,String fmt) throws ClientProtocolException, IOException{

    	String url = "http://ads.cellflare.com/Cfsrv/restservice/brand/getstorecities?";
    	url+="bi="+bi+"&fmt="+fmt;
    	String retStr = getString(url);
    	ArrayList<Store> list = new ArrayList<Store>();
        try {
        	JSONArray jarr = new JSONArray(retStr);
        	if(jarr!=null){
        		for(int i=0;i<jarr.length();i++){
        			JSONObject json=jarr.getJSONObject(i);
        			JSONArray nameArray=json.names();
        			JSONArray valArray=json.toJSONArray(nameArray);
        			Store store = new Store();
        			for(int k=0;k<nameArray.length();k++)
        			{
    				   String nameStr = nameArray.getString(k);
    				   String valueStr  =valArray.getString(k);
        			    //Log.i("RestClient",nameArray.getString(k)+":"+valArray.getString(k)+"\n");
        			    if("city".equalsIgnoreCase(nameStr)){store.setCity(valueStr);}
        			    if("prov".equalsIgnoreCase(nameStr)){store.setProv(valueStr);}
        			    if("ctry".equalsIgnoreCase(nameStr)){store.setCtry(valueStr);}
        			}
        			list.add(store);
        		}
                	
        	}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	return list;
        } 
    
    public static List<Store> getStoreCities() throws ClientProtocolException, IOException{
    	return  getStoreCities("1","json");
    }
    
    
    
    
    
    /**
     * get/search store by user's criteria (latitude/longitude or city)
     * @param bi	brandid, id of the branded app
     * @param city	City name, use + to replace  ' ', and delete "'"
     * @param prov	Province code, such as ON,  BC, CA
     * @param ctry	Code of country
     * @param la	Latitude, best keep 6 decimals
     * @param lo	Longitude, , best keep 6 decimals
     * @param r		Radius from users location , int, unit meter, default 50000 (50 km)
     * @param fmt	return format, xml/json
     * @return
     * example:http://ads.cellflare.com/Cfsrv/RESTService/brand/getbrandstores?bi=1&la=43.733852&lo=-79.33111&r=40000&fmt=xml
     */
    public static StoreInfo getBrandStores	(String bi ,String city ,String prov ,String ctry ,double la ,double lo ,int r ,String fmt){
    	if(city!=null){
    		city = city.replaceAll(" ", "+").replaceAll("'", "");
    	}

    	String url = "http://ads.cellflare.com/Cfsrv/RESTService/brand/getbrandstores?";
    	url+="bi="+bi+"&city="+city+"&prov="+prov+"&ctry="+ctry+"&la="+la+"&lo="+lo+"&r="+r+"&fmt="+fmt;
    	String retStr = getString(url);
    	Config cfg = null;
        try {
			JSONObject json=new JSONObject(retStr);
			Log.i("RestClient","<jsonobject>\n"+json.toString()+"\n</jsonobject>");

			// A Simple JSONObject Parsing
			JSONArray nameArray=json.names();
			JSONArray valArray=json.toJSONArray(nameArray);
			cfg = new Config();
			for(int i=0;i<nameArray.length();i++)
			{
//			    Log.i("RestClient","<jsonname"+i+">\n"+nameArray.getString(i)+"\n</jsonname"+i+">\n"
//			            +"<jsonvalue"+i+">\n"+valArray.getString(i)+"\n</jsonvalue"+i+">");
			   String nameStr = nameArray.getString(i);
			   String valueStr  =valArray.getString(i);
			   if("cn".equalsIgnoreCase(nameStr)){cfg.setCn      (valueStr);}
			   if("bn".equalsIgnoreCase(nameStr)){cfg.setBn      (valueStr);}
			   if("scount".equalsIgnoreCase(nameStr)){cfg.setScount  (Integer.valueOf(valueStr).intValue());}
			   if("tid".equalsIgnoreCase(nameStr)){cfg.setTid     (Integer.valueOf(valueStr).intValue());}
			   if("lver".equalsIgnoreCase(nameStr)){cfg.setLver    (valueStr);}
			   if("phone".equalsIgnoreCase(nameStr)){cfg.setPhone   (valueStr);}
			   if("ft".equalsIgnoreCase(nameStr)){cfg.setFt      (Integer.valueOf(valueStr).intValue());}
			   if("img".equalsIgnoreCase(nameStr)){cfg.setImg     (valueStr);}
			   if("img_name".equalsIgnoreCase(nameStr)){cfg.setImg_name(valueStr);}
			   if("img_ver".equalsIgnoreCase(nameStr)){cfg.setImg_ver (Integer.valueOf(valueStr).intValue());}
			}

			// A Simple JSONObject Value Pushing
			//json.put("sample key", "sample value");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	return cfg;
    
    	}

    
    
    
    
    
    /**
     * get details of a store
     * @param bi
     * @param sid
     * @param fmt
     * @return
     * example:http://ads.cellflare.com/Cfsrv/RESTService/brand/getstoredetail?bi=1&sid=1&fmt=xml
     */
    public static StoreDetail getStoreDetail	(String bi,int sid,String fmt){
    	return null;
    	}
    
    
    
    
    
    
    
    /**
     * get all coupon list for a store
     * @param bi
     * @param sid
     * @param fmt
     * @return
     * example: http://ads.cellflare.com/Cfsrv/RESTService/brand/getcouponlist?bi=1&sid=1&fmt=xml
     */
    public static BaCouponInfo getCouponList	(String bi,int sid,String fmt){
    	return null;
    	}
    
    
    
    
    
    /**
     * get the detail or coupon page or coupon image for a coupon
     * @param bi	brandid, id of the branded app
     * @param sid	Storeid
     * @param cid	Couponid
     * @param fmt	return format, xml/json/page/img
     * @param type	Only use for fmt=image, if set to icon, return small image
     * @param w	Only use for fmt=image, Width of the image
     * @param h	Only use for fmt=image, Height of the image
     * @return
     */
    public static Bitmap getCouponDetail(String bi ,int sid ,int cid ,String fmt ,String type ,int w ,int h ){return null;}	
   
    
    
    
    
    
    /**
     * get the list of flyer/menu list for a store
     * @param bi
     * @param sid
     * @param fmt
     * @return
     */
    public static FlyerInfo getFlyerList		(String bi,int sid,String fmt){
    	return null;
    	}	
    
    
    
    
    
    
    /**
     * get one flyer/menu page (mostly image) details for a flyer 
     * @param bi	 brandid, id of the branded app
     * @param sid	Store Id
     * @param fid	Flyer Id
     * @param pg	Number of page
     * @param fmt	return format, xml/json/page/image
     * @param type	Only use for fmt=image, if set to icon, return small image, if the flyer type isn't image, return null
     * @param w	Only use for fmt=image, Width of the image
     * @param h	Only use for fmt=image, Height of the image
     * @return
     * Example:http://ads.cellflare.com/Cfsrv/RESTService/brand/getflyerdetail?bi=1&sid=1&fid=137&pg=1&type=icon&h=50&w=50&fmt=image
     */
    public static Bitmap getFlyerDetail	(String bi,int sid,int fid,int pg,String fmt,String type,int w,int h){
    	return null;
    	}
    
    
    
    
    

    /**
     * For app download the newest image for app's skin
     * @param tid	 Theme ID, id of the theme the branded app currently use
     * @param name	Name of the image, such as 'background'
     * @param ver	Version of the image
     * @param size	Width x Height. resversed, ignored
     * @return
     */
    public static Bitmap getAppImage		(int tid,String name,String ver,int size){
    	return null;
    	}
    

    
    
    
    
	/**
	 * Get the app's logo if needed
	 * @param bi
	 * @param type
	 * @param w
	 * @param h
	 * @return
	 */
    public static Bitmap getLogo (String bi,String type,int w,int h){
    	return null;
    	}
    
    
    
    
    
    
    /**
     * Get the messages from server for keep the display message up to date  
     * @param bi	 brandid, id of the branded app
     * @param lan	Language,  use en-us,fr-ca, etc.  default or not found use English
     * @param ptype	 phone type
     * @param fmt	return format, xml/json
     * @return
     * Example:http://ads.cellflare.com/Cfsrv/RESTService/brand/getmessages?bi=1&lan=en-us&ptype=0
     */
    public static List<BaMessageInfo> getMessages		(String bi,String lan,String ptype,String fmt){
    	return null;
    	}  
}