/**
 * return by  	getappbasic
 */
package com.branded.android.entity;

public class Config {

	public String getCn() {
		return cn;
	}
	public void setCn(String cn) {
		this.cn = cn;
	}
	public String getBn() {
		return bn;
	}
	public void setBn(String bn) {
		this.bn = bn;
	}
	public int getScount() {
		return scount;
	}
	public void setScount(int scount) {
		this.scount = scount;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getLver() {
		return lver;
	}
	public void setLver(String lver) {
		this.lver = lver;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getFt() {
		return ft;
	}
	public void setFt(int ft) {
		this.ft = ft;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getImg_name() {
		return img_name;
	}
	public void setImg_name(String img_name) {
		this.img_name = img_name;
	}
	public int getImg_ver() {
		return img_ver;
	}
	public void setImg_ver(int img_ver) {
		this.img_ver = img_ver;
	}
	String  cn       ;
	String  bn       ;
	int     scount   ;
	int     tid      ;
	String  lver     ;
	String  phone    ;
	int     ft       ;
	String  img      ;
	String  img_name ;
	int     img_ver  ;
}
