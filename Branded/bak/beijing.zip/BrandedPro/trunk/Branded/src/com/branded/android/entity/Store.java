/**
 * (list)return by 	getstorecities
 */
package com.branded.android.entity;

public class Store {
	String ctry;// contry
	String prov;
	String city;
	public String getCtry() {
		return ctry;
	}

	public void setCtry(String ctry) {
		this.ctry = ctry;
	}

	public String getProv() {
		return prov;
	}

	public void setProv(String prov) {
		this.prov = prov;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
}
