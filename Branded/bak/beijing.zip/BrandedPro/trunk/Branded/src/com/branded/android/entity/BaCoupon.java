package com.branded.android.entity;

public class BaCoupon {
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCtitle() {
		return ctitle;
	}
	public void setCtitle(String ctitle) {
		this.ctitle = ctitle;
	}
	public String getCcode() {
		return ccode;
	}
	public void setCcode(String ccode) {
		this.ccode = ccode;
	}
	public String getCvdate() {
		return cvdate;
	}
	public void setCvdate(String cvdate) {
		this.cvdate = cvdate;
	}
	public int getCvtime() {
		return cvtime;
	}
	public void setCvtime(int cvtime) {
		this.cvtime = cvtime;
	}
	public int getCtype() {
		return ctype;
	}
	public void setCtype(int ctype) {
		this.ctype = ctype;
	}
	int    cid      ; 
	String ctitle   ; 
	String ccode    ; 
	String cvdate   ; 
	int    cvtime   ; 
	int    ctype    ; 

}
