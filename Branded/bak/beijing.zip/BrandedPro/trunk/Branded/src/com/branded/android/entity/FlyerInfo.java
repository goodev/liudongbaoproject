/**
 * return by getflyerlist
 */
package com.branded.android.entity;

import java.util.List;

public class FlyerInfo {
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public List<Flyer> getList() {
		return list;
	}
	public void setList(List<Flyer> list) {
		this.list = list;
	}
	int count;
	List<Flyer> list;
}
