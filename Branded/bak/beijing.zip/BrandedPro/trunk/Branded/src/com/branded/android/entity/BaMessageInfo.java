package com.branded.android.entity;

/**
 * @author 0188
 *
 */
public class BaMessageInfo {
	public String getMkey() {
		return mkey;
	}
	public void setMkey(String mkey) {
		this.mkey = mkey;
	}
	public String getMval() {
		return mval;
	}
	public void setMval(String mval) {
		this.mval = mval;
	}
	String mkey;
	String mval;
}
